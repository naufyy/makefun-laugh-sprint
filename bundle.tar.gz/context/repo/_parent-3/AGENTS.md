# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- Claude Code: installed at `~/.local/bin/claude` (prepend `$HOME/.local/bin` to PATH). Call headless as `claude -p "..." < /dev/null` to avoid the stdin wait warning. Auth is the user's Claude Pro subscription via `claude auth login --claudeai` (browser URL + paste-code flow, credentials stored by Claude Code itself; never read `~/.claude/.credentials.json`). Check state with `claude auth status`.
- Google Calendar （要約）: 終日予定を時刻付きに変える変更は `events patch` では失敗する（既存の start.date が残り 400 Invalid start time)。`events update`（PUT）で summary・colorId 等を含めた完全な内容を送ると変換できる。
- make.fun のリポジトリ/ペイロード作業（git・実行・キット操作）はサブエージェントに委任しない（2026-11-22 松尾が承認した運用）。委任先セッションは内容ベースの実行リスクチェックで初手から止まるのが常態化したが、メインセッション自身の exec は同内容でも通った。恒久許可はスコープ付き（タスク/接続先ごと）しか存在せず、この層には無い。定期作業は恒久許可済みジョブ（makefun-auto-daily 等）に寄せる。
